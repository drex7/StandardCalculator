# StandardCalculator
Minimal Standard Calculator using Java
